package FileSystem;

public class OutOfMemoryException extends Exception{
	public OutOfMemoryException(String message){
		super(message);
	}
}
